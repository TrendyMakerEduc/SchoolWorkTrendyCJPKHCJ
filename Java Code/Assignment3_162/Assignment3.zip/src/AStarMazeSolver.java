import maze.Cell;
import maze.Maze;
import maze.MazeSolver;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class AStarMazeSolver implements MazeSolver {

}

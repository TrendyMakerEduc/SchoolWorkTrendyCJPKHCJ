import maze.Cell;
import maze.Maze;
import maze.MazeRenderer;
import maze.MazeSolver;

import java.util.Set;

public class Asn3 {
    private static final String RELATIVE_RESOURCES = "./resources/maze/";

    public static void main(String[] args) {

    }
}

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class HuffLeafTest {

    private HuffmanLeaf classUnderTest;

    @Test
    void getWeight_onlyUseCase_returnsWeight() {

    }

    @Test
    void getCharacter_lowerCaseCharacter_returnsLowerCaseCharacter() {

    }

    @Test
    void getCharacter_upperCaseCharacter_returnsLowerCaseCharacter() {

    }

    @Test
    void toString_onlyUseCase_returnsString() {

    }

}

public interface HuffmanNode {
    int getWeight();
}

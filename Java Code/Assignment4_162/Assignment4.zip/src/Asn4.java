public class Asn4 {
    private static final String RELATIVE_RESOURCES = "./resources/";

    public static void main(String[] args) {

    }
}
